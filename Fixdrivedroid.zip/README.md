Module was currently tested on folowing devices:
1) Xiaomi Mi Note 10 lite (toco, PixelOS - Android 13)
2) Realme XT (RMX1921)
3) Razer Phone (Project Cheryl, LineageOS 19.1)
4) Google Pixel 5a 5G (Barbet, Stock Android 13)
5) Xiaomi Mi 9T (davinci, RiceDroid, A13)
6) Samsung Galaxy A22s 5G (a22x, Stock Android 11)
7) Doogie s98pro (Stock Android)
8) Redmi Note 7 (Lavender, DerpFest Tango - Android 13)
9) Samsung s21 Ultra (BeyondROM 4.4 DWA4, Android 13) - partially works, but cable disconnection during mounting will cause reboot. Troubleshooting is now in progress.
10) Google Pixel 7 pro (Stock Android)
11) Redmi 10A (Android 11 MIUI MOD)
12) Redmi 9A
